var a;
var b;
var c = "GREEN";
var d = "HILL";
var e = "ZONE";

function preload() {
  a = loadImage("greenhill1.png");
  b = loadImage("sonicframe0.png");
}

function setup() {
  createCanvas(576, 400);
  textFont("Century Schoolbook");
}

function draw() {
  background(16,16,165);
  image(a, 0, 96);
  image(b, mouseX, mouseY);
  fill(0);
  stroke(0);
  textSize(32);
  text(c, 0, 2, 32, 32);
  text(d, 120, 2, 32, 32);
  text(e, 90, 32, 32, 32);
  fill(255);
  stroke(255);
  textSize(30);
  text(c, 0, 0, 32, 30);
  text(d, 120, 0, 32, 30);
  text(e, 90, 30, 32, 30);
}