
function setup() {
    createCanvas(1024, 240);
    noStroke();
    noLoop();

    // SMB1 Day:Linear
    fillGradient('linear', {
        from: [0, 65],
        to: [0, 142],
        steps: [
		color('#508ca0'),
            	color('#c0fcf8')
        ]
    });
    rect(0, 0, 256, 240);

    // SMB1 Night:Linear
    fillGradient('linear', {
        from: [0, 65],
        to: [0, 142],
        steps: [
		color('#383c68'),
            	color('#000400')
        ]
    });
    rect(256, 0, 256, 240);

    // SMB1 Heaven:Linear
    fillGradient('linear', {
        from: [0, 65],
        to: [0, 142],
        steps: [
		color('#d0fcf8'),
            	color('#f8fcf8')
        ]
    });
    rect(512, 0, 256, 240);

    // SMB1 Water:Linear
    fill('#80a8e0');
    rect(768, 0, 256, 40);

    fillGradient('linear', {
        from: [0, 44],
        to: [0, 124],
        steps: [
		color('#4878d0'),
            	color('#001870')
        ]
    });
    rect(768, 40, 256, 200);

    // This is the p5.fillGradient library. The main function of the library is similar to that of the fill tool, but instead of filling with a solid color,  it instead fills with gradients. The library has a few example gradients such as linear, radial, and conic. I stuck with the linear graident becuase I wanted to recreate the background gradients used in the Super NES version of Super Mario Bros. and Super Mario Bros. 2.
}
