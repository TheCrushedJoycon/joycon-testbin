function setup() {
  createCanvas(400, 400);
  angleMode (DEGREES);
}

function draw() {
  background(148,148,255);
  scale(1);
  rotate(QUARTER_PI);
  for (var x = 0; x < width + 32; x += 32) {
    ground(x,368);
  }
  brick(0,112);
  brick(32,240);
  brick(224,240);
  brick(256,240);
  itembox(32,112);
  bighill(96,272);
  
  print(ground);
  print(brick);
  print(itembox);
  print(bighill);
}

function ground(x, y) {
  push();
  noStroke();
  fill(156,74,0);
  rect(x, y, 32, 32);
  fill(255,206,197);
  rect(x+2, y, 16, 2);
  rect(x+22, y, 8, 2);
  rect(x, y+2, 2, 18);
  rect(x+20, y+2, 2, 8);
  rect(x+20, y+12, 10, 2);
  rect(x, y+24, 2, 6);
  rect(x, y+22, 4, 2);
  rect(x+4, y+24, 4, 2);
  rect(x+8, y+26, 6, 2);
  rect(x+20, y+14, 2, 6);
  rect(x+18, y+20, 2, 4);
  rect(x+16, y+24, 2, 8);
  fill(0);
  rect(x, y+20, 4, 2);
  rect(x+4, y+22, 4, 2);
  rect(x+8, y+24, 6, 2);
  rect(x+2, y+30, 12, 2);
  rect(x+14, y+24, 2, 6);
  rect(x+18, y+30, 12, 2);
  rect(x+28, y+28, 4, 2);
  rect(x+30, y+12, 2, 16);
  rect(x+30, y+2, 2, 8);
  rect(x+24, y+10, 6, 2);
  rect(x+22, y+8, 2, 4);
  rect(x+18, y, 2, 20);
  rect(x+16, y+20, 2, 4);
  pop();
}


function brick(x, y) {
  push();
  noStroke();
  fill(156,74,0);
  rect(x, y, 32, 32);
  fill(255,206,197);
  rect(x, y, 32, 2);
  fill(0);
  rect(x, y+6, 32, 2);
  rect(x, y+14, 32, 2);
  rect(x, y+22, 32, 2);
  rect(x, y+30, 32, 2);
  rect(x+14, y+2, 2, 4);
  rect(x+30, y+2, 2, 4);
  rect(x+6, y+8, 2, 6);
  rect(x+22, y+8, 2, 6);
  rect(x+14, y+16, 2, 6);
  rect(x+30, y+16, 2, 6);
  rect(x+6, y+24, 2, 6);
  rect(x+22, y+24, 2, 6);
  pop();
}

function itembox(x, y) {
  push();
  noStroke();
  fill(234,158,34);
  rect(x, y+2, 32, 30);
  fill(156,74,0);
  rect(x+2, y, 28, 2);
  rect(x, y+2, 2, 28);
  rect(x+10, y+6, 10, 2);
  rect(x+8, y+8, 4, 6);
  rect(x+18, y+8, 4, 6);
  rect(x+16, y+14, 6, 2);
  rect(x+14, y+16, 4, 4);
  rect(x+14, y+22, 4, 4);
  fill(0);
  rect(x, y+30, 32, 2);
  rect(x+30, y+2, 2, 28);
  rect(x+4, y+4, 2, 2);
  rect(x+4, y+26, 2, 2);
  rect(x+26, y+4, 2, 2);
  rect(x+26, y+26, 2, 2);
  rect(x+12, y+8, 6, 2);
  rect(x+12, y+10, 2, 4);
  rect(x+10, y+14, 4, 2);
  rect(x+22, y+10, 2, 6);
  rect(x+20, y+16, 4, 2);
  rect(x+18, y+16, 2, 4);
  rect(x+16, y+20, 4, 2);
  rect(x+16, y+26, 4, 2);
  rect(x+18, y+24, 2, 2);
  pop();
}

function bighill(x, y) {
  push();
  noStroke();
  fill(57,132,0);
  beginShape();
  vertex(x,y+96);
  vertex(x+160,y+96);
  vertex(x+96,y+32);
  vertex(x+64,y+32);
  endShape();
  rect(x+68, y+30, 24, 2);
  rect(x+74, y+28, 12, 2);
  fill(0);
  rect(x, y+94, 2, 2);
  rect(x+2, y+92, 2, 2);
  rect(x+4, y+90, 2, 2);
  rect(x+6, y+88, 2, 2);
  rect(x+8, y+86, 2, 2);
  rect(x+10, y+84, 2, 2);
  rect(x+12, y+82, 2, 2);
  rect(x+14, y+80, 2, 2);
  rect(x+16, y+78, 2, 2);
  rect(x+18, y+76, 2, 2);
  rect(x+20, y+74, 2, 2);
  rect(x+22, y+72, 2, 2);
  rect(x+24, y+70, 2, 2);
  rect(x+26, y+68, 2, 2);
  rect(x+28, y+66, 2, 2);
  rect(x+30, y+64, 2, 2);
  rect(x+32, y+62, 2, 2);
  rect(x+34, y+60, 2, 2);
  rect(x+36, y+58, 2, 2);
  rect(x+38, y+56, 2, 2);
  rect(x+40, y+54, 2, 2);
  rect(x+42, y+52, 2, 2);
  rect(x+44, y+50, 2, 2);
  rect(x+46, y+48, 2, 2);
  rect(x+48, y+46, 2, 2);
  rect(x+50, y+44, 2, 2);
  rect(x+52, y+42, 2, 2);
  rect(x+54, y+40, 2, 2);
  rect(x+56, y+38, 2, 2);
  rect(x+58, y+36, 2, 2);
  rect(x+60, y+34, 2, 2);
  rect(x+62, y+32, 2, 2);
  
  rect(x+64, y+30, 4, 2);
  rect(x+68, y+28, 6, 2);
  rect(x+74, y+26, 12, 2);
  rect(x+86, y+28, 6, 2);
  rect(x+92, y+30, 4, 2);
  
  rect(x+158, y+94, 2, 2);
  rect(x+156, y+92, 2, 2);
  rect(x+154, y+90, 2, 2);
  rect(x+152, y+88, 2, 2);
  rect(x+150, y+86, 2, 2);
  rect(x+148, y+84, 2, 2);
  rect(x+146, y+82, 2, 2);
  rect(x+144, y+80, 2, 2);
  rect(x+142, y+78, 2, 2);
  rect(x+140, y+76, 2, 2);
  rect(x+138, y+74, 2, 2);
  rect(x+136, y+72, 2, 2);
  rect(x+134, y+70, 2, 2);
  rect(x+132, y+68, 2, 2);
  rect(x+130, y+66, 2, 2);
  rect(x+128, y+64, 2, 2);
  rect(x+126, y+62, 2, 2);
  rect(x+124, y+60, 2, 2);
  rect(x+122, y+58, 2, 2);
  rect(x+120, y+56, 2, 2);
  rect(x+118, y+54, 2, 2);
  rect(x+116, y+52, 2, 2);
  rect(x+114, y+50, 2, 2);
  rect(x+112, y+48, 2, 2);
  rect(x+110, y+46, 2, 2);
  rect(x+108, y+44, 2, 2);
  rect(x+106, y+42, 2, 2);
  rect(x+104, y+40, 2, 2);
  rect(x+102, y+38, 2, 2);
  rect(x+100, y+36, 2, 2);
  rect(x+98, y+34, 2, 2);
  rect(x+96, y+32, 2, 2);
  
  rect(x+90, y+32, 2, 2);
  rect(x+88, y+34, 6, 8);
  rect(x+90, y+42, 2, 2);
  rect(x+82, y+40, 4, 8);
  
  rect(x+58, y+64, 2, 2);
  rect(x+56, y+66, 6, 8);
  rect(x+58, y+74, 2, 2);
  rect(x+50, y+72, 4, 8);
  
  rect(x+106, y+64, 2, 2);
  rect(x+104, y+66, 6, 8);
  rect(x+106, y+74, 2, 2);
  rect(x+98, y+72, 4, 8);
  pop();
}